# Magic Unicorn Theme - Complete Package

## What's Included

- **Magic Unicorn Light & Dark** - KDE Look and Feel themes
- **Flat-Remix-Violet icons** - Light and dark icon themes  
- **CLI Theme Switcher** - `uc-theme-switch` command
- **SDDM Login Themes** - Magic Unicorn login screens
- **Application Dashboard** - Rainbow grid app launcher
- **Global Menu Support** - macOS-style menu integration
- **Unicorn Logo Assets** - SVG icons and branding

## Installation

### Complete Installation (Recommended)
```bash
sudo ./install-magic-unicorn.sh
```

### GUI Installation (Individual Themes)
1. Open System Settings > Appearance > Global Theme
2. Click "Get New Global Themes"
3. Install from File: `MagicUnicorn-Light-2.0.tar.gz` or `MagicUnicorn-Dark-2.0.tar.gz`

### CLI Usage
After installation:
```bash
uc-theme-switch
```

## Features

- 🦄 **Unicorn Logo** in menu button
- 🌈 **Rainbow Grid Launcher** - Full-screen app grid
- 🍎 **macOS Global Menu** - App titles in menu bar  
- 🎨 **Flat-Remix-Violet Icons** - Beautiful violet theme
- 💻 **SDDM Login Themes** - Branded login screens
- ⚡ **CLI Theme Switching** - Quick theme changes

## Requirements

- KDE Plasma 6.0+
- Qt 6.8+
- plasma-widgets-addons (for Application Dashboard)

## License

GPL-3.0 - See individual component licenses for details.
