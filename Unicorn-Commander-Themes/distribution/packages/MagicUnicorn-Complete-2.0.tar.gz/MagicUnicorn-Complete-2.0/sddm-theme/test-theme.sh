#!/bin/bash

# Quick SDDM Theme Tester
# Tests the UnicornCommander SDDM theme without installing

set -e

PURPLE='\033[0;35m'
BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${PURPLE}🦄 UnicornCommander SDDM Theme Tester${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

THEME_DIR="$(dirname "$0")/UnicornCommander"

# Check if theme directory exists
if [ ! -d "$THEME_DIR" ]; then
    echo -e "${RED}❌ Theme directory not found: $THEME_DIR${NC}"
    exit 1
fi

# Check if Main.qml exists
if [ ! -f "$THEME_DIR/Main.qml" ]; then
    echo -e "${RED}❌ Main.qml not found in theme directory${NC}"
    exit 1
fi

# Check if SDDM is available
if ! command -v sddm &> /dev/null; then
    echo -e "${RED}❌ SDDM is not installed on this system${NC}"
    exit 1
fi

echo -e "${BLUE}🧪 Testing UnicornCommander SDDM theme...${NC}"
echo -e "${YELLOW}Press Ctrl+C to exit the test${NC}"
echo ""

# Test the theme
if command -v sddm-greeter-qt6 &> /dev/null; then
    sddm-greeter-qt6 --test-mode --theme "$THEME_DIR"
elif command -v sddm-greeter &> /dev/null; then
    echo -e "${YELLOW}⚠️  Using Qt5 version (sddm-greeter). Theme is designed for Qt6.${NC}"
    sddm-greeter --test-mode --theme "$THEME_DIR"
else
    echo -e "${RED}❌ SDDM greeter not found${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}✅ Test completed!${NC}"