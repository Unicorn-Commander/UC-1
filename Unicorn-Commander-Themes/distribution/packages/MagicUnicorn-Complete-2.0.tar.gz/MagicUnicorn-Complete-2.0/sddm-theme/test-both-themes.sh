#!/bin/bash

# SDDM Themes Tester - Tests both Magic Unicorn and UnicornCommander themes
# Validates QML syntax and basic functionality

set -e

PURPLE='\033[0;35m'
BLUE='\033[0;34m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${PURPLE}🦄 UC Global Themes - SDDM Themes Tester${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

BASE_DIR="$(dirname "$0")"
MAGIC_UNICORN_DIR="$BASE_DIR/MagicUnicorn"
UNICORN_COMMANDER_DIR="$BASE_DIR/UnicornCommander"

# Function to validate QML syntax
validate_qml() {
    local theme_name="$1"
    local qml_file="$2"
    
    echo -e "${BLUE}🔍 Validating $theme_name QML syntax...${NC}"
    
    if command -v qmlscene &> /dev/null; then
        if qmlscene --quit "$qml_file" &> /dev/null; then
            echo -e "${GREEN}✅ $theme_name QML syntax is valid${NC}"
            return 0
        else
            echo -e "${RED}❌ $theme_name QML syntax has errors${NC}"
            return 1
        fi
    else
        echo -e "${YELLOW}⚠️  qmlscene not available, skipping syntax validation${NC}"
        return 0
    fi
}

# Function to check theme files
check_theme_files() {
    local theme_name="$1"
    local theme_dir="$2"
    
    echo -e "${BLUE}📁 Checking $theme_name theme files...${NC}"
    
    local files_ok=true
    
    # Check required files
    if [ ! -f "$theme_dir/Main.qml" ]; then
        echo -e "${RED}❌ Main.qml missing in $theme_name${NC}"
        files_ok=false
    fi
    
    if [ ! -f "$theme_dir/metadata.desktop" ]; then
        echo -e "${RED}❌ metadata.desktop missing in $theme_name${NC}"
        files_ok=false
    fi
    
    if [ ! -f "$theme_dir/theme.conf" ]; then
        echo -e "${RED}❌ theme.conf missing in $theme_name${NC}"
        files_ok=false
    fi
    
    if [ "$files_ok" = true ]; then
        echo -e "${GREEN}✅ All required files present for $theme_name${NC}"
    fi
    
    return $([ "$files_ok" = true ])
}

# Function to test theme with SDDM
test_theme() {
    local theme_name="$1"
    local theme_dir="$2"
    
    echo -e "${BLUE}🧪 Testing $theme_name with SDDM...${NC}"
    
    if ! command -v sddm &> /dev/null; then
        echo -e "${YELLOW}⚠️  SDDM not installed, skipping live test for $theme_name${NC}"
        return 0
    fi
    
    echo -e "${YELLOW}Testing $theme_name (Press Ctrl+C to stop)${NC}"
    
    if command -v sddm-greeter-qt6 &> /dev/null; then
        timeout 10s sddm-greeter-qt6 --test-mode --theme "$theme_dir" || true
    elif command -v sddm-greeter &> /dev/null; then
        echo -e "${YELLOW}⚠️  Using Qt5 version for $theme_name (theme designed for Qt6)${NC}"
        timeout 10s sddm-greeter --test-mode --theme "$theme_dir" || true
    else
        echo -e "${YELLOW}⚠️  SDDM greeter not available for $theme_name${NC}"
        return 0
    fi
    
    echo -e "${GREEN}✅ $theme_name test completed${NC}"
}

# Test Magic Unicorn theme
echo -e "${PURPLE}Testing Magic Unicorn (macOS style) theme...${NC}"
if [ -d "$MAGIC_UNICORN_DIR" ]; then
    check_theme_files "Magic Unicorn" "$MAGIC_UNICORN_DIR"
    validate_qml "Magic Unicorn" "$MAGIC_UNICORN_DIR/Main.qml"
    
    read -p "Test Magic Unicorn theme live? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        test_theme "Magic Unicorn" "$MAGIC_UNICORN_DIR"
    fi
else
    echo -e "${RED}❌ Magic Unicorn theme directory not found${NC}"
fi

echo ""

# Test UnicornCommander theme
echo -e "${PURPLE}Testing UnicornCommander (Windows style) theme...${NC}"
if [ -d "$UNICORN_COMMANDER_DIR" ]; then
    check_theme_files "UnicornCommander" "$UNICORN_COMMANDER_DIR"
    validate_qml "UnicornCommander" "$UNICORN_COMMANDER_DIR/Main.qml"
    
    read -p "Test UnicornCommander theme live? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        test_theme "UnicornCommander" "$UNICORN_COMMANDER_DIR"
    fi
else
    echo -e "${RED}❌ UnicornCommander theme directory not found${NC}"
fi

echo ""
echo -e "${GREEN}🎉 All theme tests completed!${NC}"
echo ""
echo -e "${BLUE}Theme Locations:${NC}"
echo -e "  • Magic Unicorn (macOS style): $MAGIC_UNICORN_DIR"
echo -e "  • UnicornCommander (Windows style): $UNICORN_COMMANDER_DIR"
echo ""
echo -e "${YELLOW}To install themes:${NC}"
echo -e "  sudo ./install-sddm-theme.sh"